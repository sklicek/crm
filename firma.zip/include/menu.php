<div data-role="navbar">
<ul>
<li><a href="index.php">Hauptseite</a></li>
<li><a href="kunden/kunden.php">Kunden</a></li>
<li><a href="lieferanten/lieferanten.php">Lieferanten</a></li>
<li><a href="rechnungen/rechnungen.php">Ausgangsrechnungen</a></li>
<li><a href="rechnungen_eingang/rechnungen.php">Eingangsrechnungen</a></li>
</ul>
</div>
