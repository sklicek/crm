<div data-role="navbar">
<ul>
<li><a href="../index.php">Hauptseite</a></li>
<li><a href="kunden.php">Kunden</a></li>
<li><a href="../rechnungen/rechnungen.php">Ausgangsrechnungen</a></li>
</ul>
</div>
