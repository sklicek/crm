<div data-role="navbar">
<ul>
<li><a href="../index.php">Hauptseite</a></li>
<li><a href="lieferanten.php">Lieferanten</a></li>
<li><a href="../rechnungen_eingang/rechnungen.php">Eingangsrechnungen</a></li>
</ul>
</div>
