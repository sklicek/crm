<div data-role="navbar">
<ul>
<li><a href="../index.php">Hauptseite</a></li>
<li><a href="../kunden/kunden.php">Kunden</a></li>
<li><a href="rechnungen.php">Ausgangsrechnungen</a></li>
<li><a href="rechnungen_view.php">Jahresübersicht</a></li>
</ul>
</div>
